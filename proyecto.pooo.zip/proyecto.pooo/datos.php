<?php
$bandera = isset($_POST['bandera']) ? $_POST['bandera'] : "";
echo $banderaE = isset($_GET['banderaE']) ? $_GET['banderaE']: "";
$id = isset($_POST['id']) ? $_POST['id'] : "";
echo $idd= isset($_GET['iddelete']) ? $_GET['iddelete']:"";
$nombre = isset($_POST['nombre']) ? $_POST['nombre'] : "";
$carrera = isset($_POST['carrera']) ? $_POST['carrera'] : "";
$edad = isset($_POST['edad']) ? $_POST['edad'] : "";
$dui = isset($_POST['dui_madre']) ? $_POST['dui_madre'] : "";


include_once('conf/conf.php');

class universidad{
    public $conexion;
    public function __construct($conexion){
        $this->conexion = $conexion;
    }

    public function select(){
        $consulta_select = 'SELECT * FROM universidad';
        $ejecutar_consultas = $this->conexion->conexion->query($consulta_select);
        return $ejecutar_consultas->fetch_all(MYSQLI_ASSOC);
    }

    public function insert($datos){
        $campos = implode(',',array_keys($datos));
        $valores = "'".implode("','",array_values($datos))."'";
        $consulta_insertar = " INSERT INTO universidad ($campos) VALUES ($valores)";
        $resultado = $this->conexion->conexion->query($consulta_insertar);
        return true;
    }

    public function selectupdate($id){
        $consultaSelect = "SELECT * FROM universidad WHERE id=$id";
        $ejecutarConsulta = $this->conexion->conexion->query($consultaSelect);
        return $ejecutarConsulta->fetch_all(MYSQLI_ASSOC);
    }

    public function update($id, $datos){
        $set = [];
        foreach ($datos as $campo => $valor){
            $set[] = "$campo = '$valor'";
        }
        $set = implode(',', $set);
        $consultaActualizar = "UPDATE `universidad` SET $set WHERE id = $id";
        $resultado = $this->conexion->conexion->query($consultaActualizar);
        if ($resultado){
            return true;
        }else{
            return $this->conexion->conexion->error;
        }
    }

    public function delete($id){
        $consultadelete="DELETE FROM universidad WHERE id=$id";
        $ejecutar_delete = $this->conexion->conexion->query($consultadelete);
        return $ejecutar_delete;
    }

}
$gestion = new universidad($conexion);

if ($bandera == 1){
    $datosInsert = array('nombre' => $nombre, 'carrera' => $carrera, 'edad' => $edad, 'dui'=> $dui) ;
    $conexion->conectar();
    $gestion->insert($datosInsert);

    if ($gestion){
        header('location:index.php');
    }
}else if($bandera == 2){
    $datosActualizar = array('nombre' => $nombre, 'carrera' => $carrera, 'edad' => $edad, 'dui'=> $dui);
    $conexion->conectar();
    $gestion->update($id, $datosActualizar);

    if ($gestion){
        header('location: index.php');
    }

    
}else if ($banderaE==3){
echo "hola";
    $conexion->conectar();
    $prueba= $gestion->delete($idd);
    if ($prueba){
        header("location: index.php");
    }
}


?>


