<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
</head>
<body>
    <!-- <h1>Bienvenidos/as</h1> -->
    <a href="registro.php">Registrar</a>
    <table border="1">
        <tr>
            <th>ID</th>
            <th>NOMBRE</th>
            <th>CARRERA</th>
            <th>EDAD</th>
            <th>DUI DE LA MADRE</th>
            <th>OPCIONES</th>
        </tr>
           
        <?php
        include_once('datos.php');
        $conexion->conectar();
        $univerdidad = $gestion->select();

        foreach ($univerdidad as $filas){
            echo"<tr>";
                echo"<td>".$filas['id']."</td>";
                echo"<td>".$filas['nombre']."</td>";
                echo"<td>".$filas['carrera']."</td>";
                echo"<td>".$filas['edad']."</td>";
                echo"<td>".$filas['dui']."</td>";
                echo"<td><a href='modificar.php?id=".$filas['id']."'>Modificar</a> "." <a href='datos.php?iddelete=".$filas['id']."&banderaE=3'>Eliminar</a></td>";
            echo"</tr>";
        }

            #$consulta = "SELECT * FROM registros";
            #$ejecutar_consulta= $conexion->conexion->query($consulta);
            /*while ($filas=mysqli_fetch_row($ejecutar_consulta)){

            }
            $conexion->desconectar();*/
        ?>
    </table>
    <br><br>

</body>
</html>

