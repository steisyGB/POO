<?php
include_once('datos.php');

$id = isset($_GET['id']) ? $_GET['id'] : "";

$conexion->conectar();
// Desarrollar el select personalizado
$universidad = $gestion->selectupdate($id);
foreach ($universidad as $filas) {
?>
    <form action="./datos.php" method="post">
        <input type="text" name="bandera" value="2" hidden="">
        <input type="text" name="id" value="<?php echo $filas['id']; ?>">
        <label for="">Nombre</label> <br>
        <input type="text" name="nombre" id="" value="<?php echo $filas['nombre']; ?>"><br>
        <label for="">Carrera</label> <br>
        <input type="text" name="carrera" id="" value="<?php echo $filas['carrera']; ?>"><br>
        <label for="">Edad</label><br>
        <input type="text" name="edad" id="" value="<?php echo $filas['edad']; ?>"><br>
        <label for="">DUI</label><br>
        <input type="text" name="dui" id="" value="<?php echo $filas['dui']; ?>"><br>
        <input type="submit" value="Enviar">
    </form>
<?php
}

// Verificar si se envió el formulario
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Obtener la nueva edad del formulario
    $nuevaEdad = $_POST['edad'];
    
    // Obtener el ID del estudiante
    $idEstudiante = $_POST['id'];
    
    // Si la nueva edad es mayor a 18, eliminar el DUI
    if ($nuevaEdad > 18) {
        $conexion->eliminarDui($idEstudiante);
    }
}
?>
