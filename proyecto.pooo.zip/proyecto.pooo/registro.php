<!-- <form action="./datos.php" method="post">
    <input type="text" name="bandera" value="1" hidden="">
    <label for="">Nombre</label> <br>
    <input type="text" name="nombre" id=""><br>
    <label for="">carrera</label> <br>
    <input type="text" name="carrera" id=""><br>
    <label for="">edad</label><br>
    <input type="text" name="edad" id=""><br><br>
    <label for="">dui</label><br>
    <input type="text" name="dui" id=""><br><br>
    <input type="submit" value="enviar">
</form>
 -->

    <form action="datos.php" method="POST">

    <input type="text" name="bandera" value="1" hidden="">
        <label for="nombre">Nombre:</label>
        <input type="text" id="nombre" name="nombre" required><br><br>

        <label for="carrera">Carrera:</label>
        <input type="text" id="carrera" name="carrera" required><br><br>

        <label for="edad">Edad:</label>
        <input type="number" id="edad" name="edad" required><br><br>

        <div id="madre_info" style="display: none;">
            <label for="dui_madre">DUI de la Madre:</label>
            <input type="text" id="dui_madre" name="dui_madre"><br><br>
        </div>

        <input type="submit" value="Registrar">
    </form>

    <script>
            document.getElementById('edad').addEventListener('change', function() {
                var edad = parseInt(this.value);
                if (edad < 18) {
                    document.getElementById('madre_info').style.display = 'block';
                } else {
                    document.getElementById('madre_info').style.display = 'none';
                }
            });
        </script>



